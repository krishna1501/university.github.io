<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <script src="/dashboard.js"></script>
  <link rel="stylesheet" href="assets/dashboard.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <style>
    .roll{
      padding-top:200px;
    }
  </style>
</head>
<body>
<?php
ob_start();
session_start();
require_once('connection.php');
?>
<?php
if(isset($_SESSION['admin'])) {
?>
<nav class="navbar navbar-expand-sm navbar-dark fixed-top outset" style="border-bottom-style: outset" >
  <div class="container-fluid">
  <!-- Brand/logo -->
  
  <a class="navbar-brand" href="dashboard.php">
    <h2>MSIT</h2>
  </a>
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <span class="nav-link" href="#"></span>
    </li>
    <li class="nav-item">
    </li>
    <li class="nav-item">
      <a class="nav-link" href="adminlogout.php"><h5>Logout</h5></a>
    </li>
  </ul>
</div>
</nav>
</div>
<div class="row" >
<div class="container-fluid">
<div class="sidenav outset" style="border-right-style: outset">
   <a href="add_faculty.php">Add Faculty</a>
  <a href="adminstdattendence.php">Student Attendence</a>
  <a href="adminstdMarks.php">Student Marks</a>
  <a href="adminelibrary.php">E-Library</a>
  <a href="faculty_List.php">Faculty List</a>
</div>
</div>
</div>
<div class="body">
  <div style="padding-top:50px;">
  <div class="container pt-3 bg-dark shadow p-4 mb-4 rounded">
    <div class="pt">
     <div class="container bg-white rounded" style="padding-left:50px;padding-right:50px;padding-top:20px;padding-bottom:10px">

        <table class="table table-bordered border border-dark">
          <thead>
           <tr>
             <th class="bg-dark text-white text-center">Professor ID </th>
             <th class="bg-dark text-white text-center">Subject Name</th>
             <th class="bg-dark text-white text-center">Slot</th>
             <th class="bg-dark text-white text-center">Action</th>
           </tr>
         </thead>
         <tbody>
           <form method="POST" action="addslotfinal.php">
           <?php
                   $sql4="select * from subject where profid = ".$row1['profid']."";
                   $result4=$conn->query($sql4);
                   if($result4->num_rows > 0) {
                   while($row4 = $result4->fetch_assoc()) {
            ?>
           <tr>
             <td width="15%">
               <div style="text-align:center">
                 <p name="pid"><?php echo $row1['profid']?></p>
                 <input type="hidden" name="sid" value="<?php echo $row1['profid']?>">
               </div>
             </td>
             <td width="10%" height="5">
               <div style="text-align:center">
                <p name="pname"><?php echo $row4['subname']?></p>
                 <input type="hidden" name="sname" value="<?php echo $row1['profid']?>">
               </div>
             </td>
                <td width="14%">
               <div style="text-align:center">
                 <select class="form-control" name="slot">
                   <?php
                    $sql5 = "select distinct slot from subject where subname = '".$row4['subname']."'";
                   $result5=$conn->query($sql5);
                   if($result5->num_rows > 0) {
                   while($row5 = $result5->fetch_assoc()) { 
                   ?>
                   <option value="<?php echo $row5['slot'];?>"><?php echo $row5['slot'];?></option>
                    <?php
                  }
                }
                    ?>
                 </select>
               </div>
             </td>
             <td width="14%">
               <div style="text-align:center">
                 <button type="submit" class="btn btn-primary">Add Faculty</button>
               </div>
             </td>
           </tr>
           <?php
         }
       }
           ?>
         </form>
           </tbody>
         </table>
       </div>
     </div>
   </div>
 </div>

</div>
<?php
}else{
  header('Location:adminlogin.php');
}
?>
</body>
</html>