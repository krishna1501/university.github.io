<!doctype html>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <script src="/dashboard.js"></script>
  <link rel="stylesheet" type="text/css" href="assets/librarystyle.css">
  <link rel="stylesheet" href="assets/dashboard.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <style>
.dropdown {
    position: relative;
    display: inline-block;
    padding-left: 45px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color:#232323;
    min-width: 130px;
    z-index: 1;
  }

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
}


.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
  </style>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark fixed-top outset" style="border-bottom-style: outset" >
  <div class="container-fluid">
  <!-- Brand/logo -->
  
  <a class="navbar-brand" href="dashboard.php">
    <h2>MSIT</h2>
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <span class="nav-link" href="#"></span>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="logout.php"><h5>Logout</h5></a>
    </li>
  </ul>
</div>
</nav>
</div>
<div class="row">
<div class="container-fluid">
<div class="sidenav outset" style="border-right-style: outset">
 <a href="timetable.php">TimeTable</a>
  <a href="StudentAttendence.php">Attendence</a>
  <a href="StudentMarks.php">Marks</a>
  <div class="dropdown">
  <a href="elibrary.php" target="_self">E-Library</a>
  <div class="dropdown-content">
    <a href="ECEbook.php">ECE</a>
    <a href="CSEbook.php" target="_self">CSE</a>
    <a href="ITbook.php">IT</a>
    <a href="EEEbook.php">EEE</a>
    <a href="MECHbook.php">MECH</a>
    <a href="CIVILbook.php">CIVIL</a>
    <a href="MASTERSbook.php">MASTERS</a>
    <a href="NEWSbook.php">NEWSPAPERS</a>
    <a href="NOVELSbook.php">NOVELS</a>
  </div>
</div>
  <a href="forum.php">Discussion Forum</a>
</div>
</div>
</div>
<div class="container">
   <div class="card-deck" style="padding-left: 210px; padding-top:120px;">
      <table>
      <?php
      $db=mysqli_connect("localhost","root","root","practicum");
      $sql = "select * from images1";
      $result=mysqli_query($db, $sql);
      $count=-1;
      if($result){

        while($row = $result->fetch_assoc()) {
          $count++;
          if($count%4==0){
           
            echo "<tr>";

            $count = 0;
          }
          echo "<td>";
          ?>
          <div class="card"  style="width:200px; height:350px;">
            <div class="card-body" id="ece">
            <img class="card-img-top" src="<?php echo $row['url']?>" alt="Card image" style="width:150px; height: 200px;"/>
          <div class="card-body">
            <h5 class="card-title" style="color:white;">
              <?php echo $row['image_text']?>
            </h5>
          <a href="<?php echo $row['image']?>">
            <button class="btn btn-warning">download</button>      
          </a>
        </div>
        </div>
        </div>
        <br>
       <?php 
    echo "</td>";
    }
      
    }

    else
    {
      echo mysql_error();
    }
      ?>
      </table>
</div>
</div>
</body>
</html>