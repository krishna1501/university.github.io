<!DOCTYPE html>
<html>
<head>
  
  <title>Register TimeTable</title>
  <link rel="icon" href="https://cdn3.iconfinder.com/data/icons/illustricon-tech-ii/512/calendar-256.png">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>


<!--            Refer RegisterTimeTable.js file for the functions            -->


<script src="assets/RegisterTimeTable.js"></script>
<!--                                                                         -->
<style>
td:hover {
    background-color: grey;
}
td{
  height:100px;
}
table{
  table-layout: auto;
}
button:dropdown{
}
</style>
<link rel="stylesheet" href="assets/UMS.css">
</head>
<body>
  <form method="POST" action="slots.php">
<?php
ob_start();
session_start();
require('connection.php');
if(isset($_SESSION['rollnumber'])){
  $sql2="select status from logindetails where rollnumber='".$_SESSION['rollnumber']."'";
$result2 = $conn->query($sql2);
if($row2 = $result2->fetch_assoc()) {
  if($row2['status']==0){
  $sql='select distinct subid,subname,credits,Classnumber from subject';
  $result = $conn->query($sql);
  if($result->num_rows > 0) {
?>
  <h1 style="text-align:center">Register your semester Time Table</h1>
<!--<div class="container bg-dark shadow p-4 mb-4 rounded col-sm-3" id="countdowncontainer">
      <center><h1 id="countdown"></h1></center>
</div>-->
  <div class="container pt-3 bg-dark shadow p-4 mb-4 rounded">
    <div class="pt">
     <div class="container bg-white rounded" style="padding-left:50px;padding-right:50px;padding-top:20px;padding-bottom:10px">
        <table class="table table-bordered border border-dark">
          <thead>
           <tr>
             <th class="bg-dark text-white">Subject Name</th>
             <th class="bg-dark text-white">Professor(s)</th>
             <th class="bg-dark text-white">Subject Code</th>
             <th class="bg-dark text-white">Credits</th>
           </tr>
         </thead>
         <tbody>
          <?php
          while($row = $result->fetch_assoc()) {
          ?>
         <input type="hidden" name="<?php echo "sclassnum".$row['subid']?>" value="<?php echo $row['Classnumber']; ?>">
           <tr>
             <td>
               <div id="<?php echo "S".$row['subid'];?>" value="Subject 1"><?php echo $row['subname'];?></div>
             </td>
             <td>
               
                <div class="form-group" id="SelectProfessorRow1">
                <select class="form-control" id="<?php echo $row['subid']?>" name="<?php echo "sub".$row['subid']?>">
                <option id="selectprofessor" value="none">Select Professor</option>
                 <?php
                   $sql1="select p.profname,s.slot from subject as s join professor as p on s.profid=p.profid and subid='".$row['subid']."'";
                   $result1 = $conn->query($sql1);
                     if ($result1->num_rows > 0) {
                    while($row1 = $result1->fetch_assoc()) {
                 ?>
                <option id="<?php echo $row1['slot'];?>" value="<?php echo $row1['slot'];?>"><?php echo $row1['profname']."----".$row1['slot'];?></option>
              <?php
               }
             }
                ?>
                </select>
              </div>
             </td>
             
             <td>
               <h6 id="<?php echo "S".$row['subid']."code";?>" name="<?php echo "sc".$row['subid'];?>"><?php echo "SUB".$row['subid'];?></h6>
             </td>
             <td>
               <h6><?php echo $row['credits'];?></h6>
             </td>
           </tr>
           <?php
             }
             }else{
              echo "norowsretrived";
              }
            ?>
         </tbody>
        </table>
     </div>
    </div>
    <div class="containder-fluid pt-2">
    <button class="btn btn-primary btn-lg btn-block" style="align:center" id="tablesubmit">Submit</button>
  </div>
  </div>
</div>
</form>
  <div class="pt-5">
    <div class="container shadow p-4 mb-4 bg-dark shadow-lg p-3 mb-5 rounded">
      <div class="pt">
      <h3 class="text-white" style="text-align:center">Time Table</h3>
        <div class="container bg-white rounded
        " style="padding-left:50px;padding-right:50px;padding-top:20px;padding-bottom:10px">
          <table class="table table-bordered border border-dark col-*-10" id="timetable">
   <thead>
    <tr>
      <th class="bg-dark text-white">Days/Periods</th>
      <th class="bg-dark text-white">1st Period<br><i>09:00-09:50</i></th>
      <th class="bg-dark text-white">2nd Period<br><i>09:55-10:45</i></th>
      <th class="bg-dark text-white">3rd period<br><i>10:55-11:45</i></th>
      <th class="bg-dark text-white">4th Period<br><i>11:50-12:40</i></th>
      <th class="bg-dark text-white">Lunch Break<br><i>12:40-01:40</i></th>
      <th class="bg-dark text-white">5th Period<br><i>01:40-02:30</i></th>
      <th class="bg-dark text-white">6th Period<br><i>02:35-03:25</i></th>
      <th class="bg-dark text-white">7th Period<br><i>03:35-04:25</i></th>
      <th class="bg-dark text-white">8th Period<br><i>04:30-05:20</i></th>
    </tr>
  </thead>
  <tbody>
    <!--******************************Monday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Monday</th>
      <!--1st period start-->
      <td id="r1c1">
        <p id="sr1c1"></p>
        <p id="pr1c1"></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r1c2">
        <p id="sr1c2"></p>
        <p id="pr1c2"></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r1c3">
        <p id="sr1c3"></p>
        <p id="pr1c3"></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r1c4">
        <p id="sr1c4"></p>
        <p id="pr1c4"></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">B</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r1c5">
        <p id="sr1c5"></p>
        <p id="pr1c5"></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r1c6">
        <p id="sr1c6"></p>
        <p id="pr1c6"></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r1c7">
        <p id="sr1c7"></p>
        <p id="pr1c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r1c8">
        <p id="sr1c8"></p>
        <p id="pr1c8"></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Tuesday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Tuesday</th>
      <!--1st period start-->
      <td id="r2c1">
        <p id="sr2c1"></p>
        <p id="pr2c1"></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r2c2">
        <p id="sr2c2"></p>
        <p id="pr2c2"></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r2c3">
        <p id="sr2c3"></p>
        <p id="pr2c3"></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r2c4">
        <p id="sr2c4"></p>
        <p id="pr2c4"></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">R</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r2c5">
        <p id="sr2c5"></p>
        <p id="pr2c5"></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r2c6">
        <p id="sr2c6"></p>
        <p id="pr2c6"></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r2c7">
        <p id="sr2c7"></p>
        <p id="pr2c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r2c8">
        <p id="sr2c8"></p>
        <p id="pr2c8"></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Wednesday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Wednesday</th>
      <!--1st period start-->
      <td id="r3c1">
        <p id="sr3c1"></p>
        <p id="pr3c1"></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r3c2">
        <p id="sr3c2"></p>
        <p id="pr3c2"></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r3c3">
        <p id="sr3c3"></p>
        <p id="pr3c3"></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r3c4">
        <p id="sr3c4"></p>
        <p id="pr3c4"></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">E</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r3c5">
        <p id="sr3c5"></p>
        <p id="pr3c5"></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r3c6">
        <p id="sr3c6"></p>
        <p id="pr3c6"></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r3c7">
        <p id="sr3c7"></p>
        <p id="pr3c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r3c8">
        <p id="sr3c8"></p>
        <p id="pr3c8"></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Thursday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Thursday</th>
      <!--1st period start-->
      <td id="r4c1">
        <p id="sr4c1"></p>
        <p id="pr4c1"></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r4c2">
        <p id="sr4c2"></p>
        <p id="pr4c2"></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r4c3">
        <p id="sr4c3"></p>
        <p id="pr4c3"></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r4c4">
        <p id="sr4c4"></p>
        <p id="pr4c4"></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">A</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r4c5">
        <p id="sr4c5"></p>
        <p id="pr4c5"></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r4c6">
        <p id="sr4c6"></p>
        <p id="pr4c6"></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r4c7">
        <p id="sr4c7"></p>
        <p id="pr4c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r4c8">
        <p id="sr4c8"></p>
        <p id="pr4c8"></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Friday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Friday</th>
      <!--1st period start-->
      <td id="r5c1">
        <p><div id="sr5c1"></div></p>
        <p><div id="pr5c1"></div></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r5c2">
        <p id="sr5c2"></div></p>
        <p id="pr5c2"></div></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r5c3">
        <p id="sr5c3"></p>
        <p id="pr5c3"></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r5c4">
        <p id="sr5c4"></p>
        <p id="pr5c4"></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">K</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r5c5">
        <p id="sr5c5"></p>
        <p id="pr5c5"></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r5c6">
        <p id="sr5c6"></p>
        <p id="pr5c6"></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r5c7">
        <p id="sr5c7"></p>
        <p id="pr5c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r5c8">
        <p id="sr5c8"></p>
        <p id="pr5c8"></p>
      </td>
      <!--8th period end-->
    </tr>
  </tbody>
</table>
<br>
       </div>
     </div>
    </div>
  </div>
  <?php
    }else{
    header('Location:timetable.php');
    }
    }
  }else{
    header('Location:Logint.php');
  }
?>  
</body>
</html>