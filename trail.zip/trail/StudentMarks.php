<!doctype html>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <script>
function color(){
    if(
      document.getElementsByClassName("attendancelist").value=="absent"){
      $(".attendancelist").css("background-color","#ffb90f");
      $(".attendancelist").css("color","white");
      $(".presentorabsent").css("background-color","white");
      $(".presentorabsent").css("color","black");
      $(".present").css("background-color","white");
      $(".present").css("color","black");
      $(".absent").css("background-color","white");
      $(".absent").css("color","black");
    }}
  </script>
  <!--<script src="/dashboard.js"></script>-->
  <link rel="stylesheet" href="assets/dashboard.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <!--<script src="assets/Attendance.js1"></script>-->
</head>
<body style="background-color:#FFA500">
<?php
require_once('connection.php');
ob_start();
session_start();
if(isset($_SESSION['rollnumber'])) {
?>
<nav class="navbar navbar-expand-sm navbar-dark fixed-top outset" style="border-bottom-style: outset" >
  <div class="container-fluid">
  <!-- Brand/logo -->
  
  <a class="navbar-brand" href="dashboard.php">
    <h2>MSIT</h2>
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <span class="nav-link" href="#"></span>
    </li>
    <li class="nav-item">
    </li>
    <li class="nav-item">
      <a class="nav-link" href="logout.php"><h5>Logout</h5></a>
    </li>
  </ul>
</div>
</nav>
</div>
<div class="row" >
<div class="container-fluid">
<div class="sidenav outset" style="border-right-style: outset">
  <a href="timetable.php" target="_self">TimeTable</a>
  <a href="StudentAttendence.php">Attendence</a>
  <a href="StudentMarks.php">Marks</a>
  <a href="elibrary.php">E-Library</a>
  <a href="forum.php">Discussion Forum</a>
</div>
</div>
</div>
<div class="body">
  <div style="padding-top:50px;">
  <div class="container pt-3 bg-dark shadow p-4 mb-4 rounded">
    <div class="pt">
     <div class="container bg-white rounded" style="padding-left:50px;padding-right:50px;padding-top:20px;padding-bottom:10px">
        <table class="table table-bordered border border-dark">
          <thead>
           <tr>
             <th class="bg-dark text-white text-center">Subject ID</th>
             <th class="bg-dark text-white text-center">CAT1 (15)</th>
             <th class="bg-dark text-white text-center">CAT2 (15)</th>
             <th class="bg-dark text-white text-center">Project (20)</th>
             <th class="bg-dark text-white text-center">External (50)</th>
             <th class="bg-dark text-white text-center">Total Marks</th>
           </tr>
         </thead>

         <tbody>
           <?php
              $sql1 = "select distinct subid from marks where rollnumber='".$_SESSION['rollnumber']."'";
              $result1 = $conn->query($sql1); 
              if($result1->num_rows > 0)
              {
                while($row1 = $result1->fetch_assoc())
                {
            ?>  
             
           <tr>
             <td width="15%">
               <div style="text-align:center" id="subjectid" name="Subjectid">
         <p><?php echo $row1['subid']?></p>
         </div>
             </td>
             <td width="10%" height="5">
               <div style="align:center">
                <?php
                    $sql2 = "select totalmarks from marks where examtype='cat1' and rollnumber = '".$_SESSION['rollnumber']."' and subid = ".$row1['subid']."";
                    $result2 = $conn->query($sql2);
                    $row2 = $result2->fetch_assoc();
                ?>
                 <p><?php echo $row2['totalmarks']?></p>
               </div>
             </td>
             <td width="10%">
               <div>
                 <?php
                    $sql2 = "select totalmarks from marks where examtype='cat2' and rollnumber = '".$_SESSION['rollnumber']."' and subid = ".$row1['subid']."";
                    $result2 = $conn->query($sql2);
                    $row3 = $result2->fetch_assoc();
                ?>
                 <p><?php echo $row3['totalmarks']?></p>
               </div>
             </td>
             <td width="10%">
               <div>
                 <?php
                    $sql2 = "select totalmarks from marks where examtype='project' and rollnumber = '".$_SESSION['rollnumber']."' and subid = ".$row1['subid']."";
                    $result2 = $conn->query($sql2);
                    $row4 = $result2->fetch_assoc();
                ?>
                 <p><?php echo $row4['totalmarks']?></p>
               </div>
             </td>
             <td width="10%">
               <div>
                 <?php
                    $sql2 = "select totalmarks from marks where examtype='external' and rollnumber = '".$_SESSION['rollnumber']."' and subid = ".$row1['subid']."";
                    $result2 = $conn->query($sql2);
                    $row5 = $result2->fetch_assoc();
                ?>
                <?php
                  $t1 = ($row2['totalmarks']+$row3['totalmarks'])/2;
                  $t2 = ($t1/100)*30;
                  $t3 = ($row4['totalmarks']/5);
                  $t4 = ($row5['totalmarks']/2);
                  $res = $t2+$t3+$t4;
                ?>
                 <p><?php echo $row5['totalmarks']?></p>
               </div>
             </td>
             <td width="10%">
               <div class="text-center">
                 <p><?php echo $res?></p>
               </div>
             </td>
           </tr>
           <?php
              }
              }
           ?>
         </tbody>
       </table>
       </div>
     </div>
   </div>
 </div>
 <?php
}
 ?>
</body>
</html>