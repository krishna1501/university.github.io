<?php
require('connection.php');
$pname=$_POST['pname'];
$password=$_POST['password'];
$subid=$_POST['subid'];
#echo"****";
$sql="insert into professor (profname,password) values('".$pname."','".$password."')";
#echo $sql;
$result=$conn->query($sql);
#echo $result;
$sql1="select profid from professor where profname='".$pname."'";
#echo $sql1;
$result1=$conn->query($sql1);
if($result1->num_rows > 0) {
    if($row1 = $result1->fetch_assoc()) {
    	$sqlsub="select distinct subid,subname,credits,classnumber from subject where subid=".$subid."";
 #   	echo $sqlsub;
    	$resultsub=$conn->query($sqlsub);

	if($resultsub->num_rows > 0) {
    if($rowsub = $resultsub->fetch_assoc()) {
    	$sql2="insert into subject(subid,subname,profid,slot,credits,classnumber)values(".$rowsub['subid'].",'".$rowsub['subname']."',".$row1['profid'].",null,".$rowsub['credits'].",".$rowsub['classnumber'].") ";
    		$resultsub=$conn->query($sql2);
  #  		echo $sql2;
    		include('Addslot.php');
					}
				}
			}
		}
?>