<?php
require('connection.php');
$pid=$_POST['sid'];
$sname=$_POST['sname'];
$slot=$_POST['slot'];
$sql="update subject set slot='".$slot."' where profid=".$pid."";
#echo $sql;
$result=$conn->query($sql);
header('Location:success1.php');
?>