<?php
    require("connection.php");
	$rollnum= $_POST['rollnum'];
	$password=$_POST['password'];
	$ret="select * from admin where username='".$rollnum."' and password='".$password."'";
	$re=$conn->query($ret);
	$row=mysqli_fetch_row($re);
	if(mysqli_num_rows($re)>0)
	{
		session_start();
		$_SESSION['admin']=$rollnum;
	header('Location:admindashboard.php');	
	}
	else
	{
		header('Location:adminlogin.php');	
	}
	?>