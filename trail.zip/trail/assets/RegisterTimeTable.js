$(document).ready(function(){
  <!--********Slot selection of subject 1*********-->
  var r1=0;
  var r2=0;
  var r3=0;
  var r4=0;
  var r5=0;
  $( "#2" ).change(function () {
    if(document.getElementById("2").value == document.getElementById("A1").value){
      $("#r1c1").css("background-color","yellow");
      $("#r2c7").css("background-color","yellow");
      $("#r4c2").css("background-color","yellow");
      $("#r3c5").css("background-color","yellow");
      $("#r3c6").css("background-color","yellow");
      $("#r3c4").css("background-color","white");
      $("#r2c2").css("background-color","white");
      $("#r5c1").css("background-color","white");
      $("#r4c5").css("background-color","white");
      $("#r4c6").css("background-color","white");
      r1=r1+1;
    }
    else if(document.getElementById("2").value == document.getElementById("A2").value){
      $("#r3c4").css("background-color","yellow");
      $("#r2c2").css("background-color","yellow");
      $("#r5c1").css("background-color","yellow");
      $("#r4c5").css("background-color","yellow");
      $("#r4c6").css("background-color","yellow");
      $("#r1c1").css("background-color","white");
      $("#r2c7").css("background-color","white");
      $("#r4c2").css("background-color","white");
      $("#r3c5").css("background-color","white");
      $("#r3c6").css("background-color","white");
      r1=r1+2;
    }
    else{
      $("#r1c1").css("background-color","white");
      $("#r2c7").css("background-color","white");
      $("#r4c2").css("background-color","white");
      $("#r3c5").css("background-color","white");
      $("#r3c6").css("background-color","white");
      $("#r3c4").css("background-color","white");
      $("#r2c2").css("background-color","white");
      $("#r5c1").css("background-color","white");
      $("#r4c5").css("background-color","white");
      $("#r4c6").css("background-color","white");
    }
  });
  <!--******************************************Ending******************************************************-->
  <!--**********Slot selection of subject 2**********-->
  $( "#1" ).change(function () {
    if(document.getElementById("1").value == document.getElementById("B1").value){
      $("#r1c3").css("background-color","yellow");
      $("#r3c1").css("background-color","yellow");
      $("#r2c4").css("background-color","yellow");
      $("#r4c3").css("background-color","yellow");
      $("#r1c5").css("background-color","white");
      $("#r2c1").css("background-color","white");
      $("#r3c3").css("background-color","white");
      $("#r5c4").css("background-color","white");
      r2=r2+1;
    }
    else if(document.getElementById("1").value == document.getElementById("B2").value){
      $("#r1c5").css("background-color","yellow");
      $("#r2c1").css("background-color","yellow");
      $("#r3c3").css("background-color","yellow");
      $("#r5c4").css("background-color","yellow");
      $("#r1c3").css("background-color","white");
      $("#r3c1").css("background-color","white");
      $("#r2c4").css("background-color","white");
      $("#r4c3").css("background-color","white");
      r2=r2+2;
    }
    else{
      $("#r1c3").css("background-color","white");
      $("#r3c1").css("background-color","white");
      $("#r2c4").css("background-color","white");
      $("#r4c3").css("background-color","white");
      $("#r1c5").css("background-color","white");
      $("#r2c1").css("background-color","white");
      $("#r3c3").css("background-color","white");
      $("#r5c4").css("background-color","white");
    }
  });
  <!--******************************************Ending******************************************************-->
  <!--Slot selection of subject 3-->
  $( "#3" ).change(function () {
    if(document.getElementById("3").value == document.getElementById("C1").value){
      $("#r1c2").css("background-color","yellow");
      $("#r4c4").css("background-color","yellow");
      $("#r5c2").css("background-color","yellow");
      $("#r1c6").css("background-color","white");
      $("#r2c5").css("background-color","white");
      $("#r4c1").css("background-color","white");
      r3=r3+1;
    }
    else if(document.getElementById("3").value == document.getElementById("C2").value){
      $("#r1c6").css("background-color","yellow");
      $("#r2c5").css("background-color","yellow");
      $("#r4c1").css("background-color","yellow");
      $("#r1c2").css("background-color","white");
      $("#r4c4").css("background-color","white");
      $("#r5c2").css("background-color","white");
      r3=r3+2;
    }
    else{
      $("#r1c2").css("background-color","white");
      $("#r4c4").css("background-color","white");
      $("#r5c2").css("background-color","white");
      $("#r1c6").css("background-color","white");
      $("#r2c5").css("background-color","white");
      $("#r4c1").css("background-color","white");
    }
  });
  <!--******************************************Ending******************************************************-->
  <!--Slot selection of subject 4-->
  $( "#4" ).change(function () {
    if(document.getElementById("4").value == document.getElementById("D1").value){
      $("#r2c3").css("background-color","yellow");
      $("#r5c3").css("background-color","yellow");
      $("#r5c6").css("background-color","yellow");
      $("#r1c4").css("background-color","white");
      $("#r3c2").css("background-color","white");
      $("#r5c5").css("background-color","white");
      r4=r4+1;
    }
    else if(document.getElementById("4").value == document.getElementById("D2").value){
      $("#r2c3").css("background-color","white");
      $("#r5c3").css("background-color","white");
      $("#r5c6").css("background-color","white");
      $("#r1c4").css("background-color","yellow");
      $("#r3c2").css("background-color","yellow");
      $("#r5c5").css("background-color","yellow");
      r4=r4+2;
    }
    else{
      $("#r2c3").css("background-color","white");
      $("#r5c3").css("background-color","white");
      $("#r5c6").css("background-color","white");
      $("#r1c4").css("background-color","white");
      $("#r3c2").css("background-color","white");
      $("#r5c5").css("background-color","white");
    }
  });
  <!--******************************************Ending******************************************************-->
  <!--Slot selection of subject 5-->
  $( "#5" ).change(function () {
    if(document.getElementById("5").value == document.getElementById("E1").value){
      $("#r1c7").css("background-color","yellow");
      $("#r2c8").css("background-color","yellow");
      $("#r2c6").css("background-color","white");
      $("#r1c8").css("background-color","white");
      r5=r5+1;
    }
    else if(document.getElementById("5").value == document.getElementById("E2").value){
      $("#r2c6").css("background-color","yellow");
      $("#r1c8").css("background-color","yellow");
      $("#r1c7").css("background-color","white");
      $("#r2c8").css("background-color","white");
      r5=r5+2;
    }
    else{
      $("#r2c6").css("background-color","white");
      $("#r1c8").css("background-color","white");
      $("#r1c7").css("background-color","white");
      $("#r2c8").css("background-color","white");
    }
  });

  <!--******************************************Ending******************************************************-->
$("#tablesubmit").click(function(){
  if(r1 == 0 || r2 == 0 || r3 == 0 || r4 == 0 || r5 == 0){
    alert("Complete the slot selections");
  }
  else{

  if(r1 == 1){

    <!--Subject 1 name and professor A1-->

    <!--1-->

    document.getElementById("sr1c1").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr1c1").innerHTML = document.getElementById("A1").value;

    <!--2-->

    document.getElementById("sr2c7").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr2c7").innerHTML = document.getElementById("A1").value;

    <!--3-->

    document.getElementById("sr4c2").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr4c2").innerHTML = document.getElementById("A1").value;

    <!--4-->

    document.getElementById("sr3c5").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr3c5").innerHTML = document.getElementById("A1").value;

    <!--5-->

    document.getElementById("sr3c6").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr3c6").innerHTML = document.getElementById("A1").value;
  }
  else if(r1 == 2){
    <!--Subject 1 name and professor A2-->

    <!--1-->

    document.getElementById("sr3c4").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr3c4").innerHTML = document.getElementById("A2").value;

    <!--2-->

    document.getElementById("sr2c2").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr2c2").innerHTML = document.getElementById("A2").value;

    <!--3-->

    document.getElementById("sr5c1").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr5c1").innerHTML = document.getElementById("A2").value;

    <!--4-->

    document.getElementById("sr4c5").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr4c5").innerHTML = document.getElementById("A2").value;

    <!--5-->

    document.getElementById("sr4c6").innerHTML = document.getElementById("S1code").textContent;
    document.getElementById("pr4c6").innerHTML = document.getElementById("A2").value;
  }
  if(r2 == 1){
    <!--Subject 2 name and professor B1-->

    <!--1-->

    document.getElementById("sr1c3").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr1c3").innerHTML = document.getElementById("B1").value;

    <!--2-->

    document.getElementById("sr3c1").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr3c1").innerHTML = document.getElementById("B1").value;

    <!--3-->

    document.getElementById("sr2c4").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr2c4").innerHTML = document.getElementById("B1").value;

    <!--4-->

    document.getElementById("sr4c3").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr4c3").innerHTML = document.getElementById("B1").value;
  }
  else if(r2 == 2){

    <!--Subject 2 name and professor B2-->

    <!--1-->

    document.getElementById("sr1c5").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr1c5").innerHTML = document.getElementById("B2").value;

    <!--2-->

    document.getElementById("sr2c1").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr2c1").innerHTML = document.getElementById("B2").value;

    <!--3-->

    document.getElementById("sr3c3").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr3c3").innerHTML = document.getElementById("B2").value;

    <!--4-->

    document.getElementById("sr5c4").innerHTML = document.getElementById("S2code").textContent;
    document.getElementById("pr5c4").innerHTML = document.getElementById("B2").value;
  }
  if(r3 == 1){

    <!--Subejct 3 name and professor C1-->

    <!--1-->

    document.getElementById("sr1c2").innerHTML = document.getElementById("S3code").textContent;
    document.getElementById("pr1c2").innerHTML = document.getElementById("C1").value;

    <!--2-->

    document.getElementById("sr4c4").innerHTML = document.getElementById("S3code").textContent;
    document.getElementById("pr4c4").innerHTML = document.getElementById("C1").value;

    <!--3-->

    document.getElementById("sr5c2").innerHTML = document.getElementById("S3code").textContent;
    document.getElementById("pr5c2").innerHTML = document.getElementById("C1").value;
  }
  else if(r3 == 2){

    <!--Subject 3 name and professor C2-->
    <!--1-->

    document.getElementById("sr1c6").innerHTML = document.getElementById("S3code").textContent;
    document.getElementById("pr1c6").innerHTML = document.getElementById("C2").value;

    <!--2-->

    document.getElementById("sr2c5").innerHTML = document.getElementById("S3code").textContent;
    document.getElementById("pr2c5").innerHTML = document.getElementById("C2").value;

    <!--3-->

    document.getElementById("sr4c1").innerHTML = document.getElementById("S3code").textContent;
    document.getElementById("pr4c1").innerHTML = document.getElementById("C2").value;
  }
  if(r4 == 1){
    <!--Subject 4 name and professor D1-->

    <!--1-->

    document.getElementById("sr2c3").innerHTML = document.getElementById("S4code").textContent;
    document.getElementById("pr2c3").innerHTML = document.getElementById("D1").value;

    <!--2-->

    document.getElementById("sr5c3").innerHTML = document.getElementById("S4code").textContent;
    document.getElementById("pr5c3").innerHTML = document.getElementById("D1").value;

    <!--3-->

    document.getElementById("sr5c6").innerHTML = document.getElementById("S4code").textContent;
    document.getElementById("pr5c6").innerHTML = document.getElementById("D1").value;
  }
  else if(r4 == 2){
    <!--Subject 4 name and professor D2-->

    <!--1-->

    document.getElementById("sr1c4").innerHTML = document.getElementById("S4code").textContent;
    document.getElementById("pr1c4").innerHTML = document.getElementById("D2").value;

    <!--2-->

    document.getElementById("sr3c2").innerHTML = document.getElementById("S4code").textContent;
    document.getElementById("pr3c2").innerHTML = document.getElementById("D2").value;

	
    <!--3-->

    document.getElementById("sr5c5").innerHTML = document.getElementById("S4code").textContent;
    document.getElementById("pr5c5").innerHTML = document.getElementById("D2").value;
  }
  if(r5 == 1){
    <!--Subject 5 name and professor E1-->

    <!--1-->

    document.getElementById("sr1c7").innerHTML = document.getElementById("S5code").textContent;
    document.getElementById("pr1c7").innerHTML = document.getElementById("E1").value;

    <!--2-->

    document.getElementById("sr2c8").innerHTML = document.getElementById("S5code").textContent;
    document.getElementById("pr2c8").innerHTML = document.getElementById("E1").value;
  }
  else if(r5 == 2){
    <!--Subejct 5 name and professor E2-->

    <!--1-->

    document.getElementById("sr2c6").innerHTML = document.getElementById("S5code").textContent;
    document.getElementById("pr2c6").innerHTML = document.getElementById("E2").value;

    <!--2-->

    document.getElementById("sr1c8").innerHTML = document.getElementById("S5code").textContent;
    document.getElementById("pr1c8").innerHTML = document.getElementById("E2").value;
  }
}
});
});