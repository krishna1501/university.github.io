var fl=0;
var fn=0;
var mn=0;
var ln=0;
var dt=0;
var e=0;
var pn=0;
var pn1=0;
var p=0;

function validatefname(){
		var fname=document.forms["student"]["fname"].value;
		if(fname.match(/^[A-Za-z]*$/))
		{
		console.log("true");
		fl =1;
		document.getElementById("message_fname").innerHTML="&#9989";
		document.getElementById("message_fname").style.color="green";
		}
		else
		{
		console.log("false");
		fl =0;
		document.getElementById("message_fname").innerHTML="&#10006";
		document.getElementById("message_fname").style.color="red";
		}
}
function validatemname(){
		var mname=document.forms["student"]["mname"].value;
		if(mname.match(/^[A-Za-z]*$/))
		{
		console.log("true");
		mn =1;
		document.getElementById("message_mname").innerHTML="&#9989";
		document.getElementById("message_mname").style.color="green";
		}
		else
		{
		console.log("false");
		mn =0;
		document.getElementById("message_mname").innerHTML="&#10006";
		document.getElementById("message_mname").style.color="red";
		}
}
function validatelname(){
		var lname=document.forms["student"]["lname"].value;
		if(lname.match(/^[A-Za-z]*$/))
		{
		console.log("true");
		ln =1;
		document.getElementById("message_lname").innerHTML="&#9989";
		document.getElementById("message_fname").style.color="green";
		}
		else
		{
		console.log("false");
		ln =0;
		document.getElementById("message_lname").innerHTML="&#10006";
		document.getElementById("message_lname").style.color="red";
		}
}

function validateusername(){
		var fullname=document.forms["student"]["fullname"].value;
		if(fullname.match(/^[A-Za-z]*$/))
		{
		console.log("true");
		fl =1;
		document.getElementById("message_fullname").innerHTML="&#9989";
		document.getElementById("message_fullname").style.color="green";
		}
		else
		{
		console.log("false");
		fl =0;
		document.getElementById("message_fullname").innerHTML="&#10006";
		document.getElementById("message_fullname").style.color="red";
		}
}
function validateemail(){
		var email=document.forms["student"]["email"].value;
		if(email.match(/^[A-Za-z0-9_$\-\.]*@{1}[a-z]*[\.]{1}[a-z]*$/))
		{
		console.log("true");
		e =1;
		document.getElementById("message_email").innerHTML="&#9989";
		document.getElementById("message_email").style.color="green";
		}
		else
		{
		console.log("false");
		e =0;
		document.getElementById("message_email").innerHTML="&#10006";
		document.getElementById("message_email").style.color="red";
		}
}

function validatephonenumber(){
		var phonenumber=document.forms["student"]["phonenumber"].value;
		if(phonenumber.match(/^[0-9]{10}$/))
		{
		console.log("true");
		pn =1;
		document.getElementById("message_phonenumber").innerHTML="&#9989";
		document.getElementById("message_phonenumber").style.color="green";
		}
		else
		{
		console.log("false");
		pn =0;
		document.getElementById("message_phonenumber").innerHTML="&#10006";
		document.getElementById("message_phonenumber").style.color="red";
		}
}
function validatephonenumber1(){
		var rephonenumber=document.forms["student"]["rephonenumber"].value;
		if(rephonenumber.match(/^[0-9]{10}$/))
		{
		console.log("true");
		pn1 =1;
		document.getElementById("message_rephonenumber").innerHTML="&#9989";
		document.getElementById("message_rephonenumber").style.color="green";
		}
		else
		{
		console.log("false");
		pn1 =0;
		document.getElementById("message_rephonenumber").innerHTML="&#10006";
		document.getElementById("message_rephonenumber").style.color="red";
		}
}

function validatepassword(){
	var password=document.forms["student"]["password"].value;
	if(password.match(/^[A-z]{1}[a-z]*[0-9]{2}$/))
		{
		p = 1;
		console.log("true");
		document.getElementById("message_password").innerHTML="&#9989";
		document.getElementById("message_password").style.color="green";
		}
		else{
			p =0;
	    console.log("false");
		document.getElementById("message_password").innerHTML="&#10006";
		document.getElementById("message_password").style.color="red";
		}
}

var fl=0;
var dt=0;
var e=0;
var pn=0;
var pn1=0;
var p=0;
function submit1(){
if(fl == 1 && dt==1 && e == 1 && pn == 1 && pn1 == 1 && p ==1 && ln==0 && fn==0 && mn==0)
{
	return true;
}
else{
	return false;
	alert("please enter valid details");
}
}