var un = 0;
var pswd =0;
function validateusername(){
		var rollnum=document.forms["student"]["rollnum"].value;
		if(rollnum.match(/^[0-9]{2}[A-za-z]{3,4}[0-9]{1,2}$/))
		{
		console.log("true");
		un =1;
		document.getElementById("message_rollnum").innerHTML="&#9989";
		document.getElementById("message_rollnum").style.color="green";
		}
		else
		{
		console.log("false");
		un =0;
		document.getElementById("message_rollnum").innerHTML="&#10006";
		document.getElementById("message_rollnum").style.color="red";
		}
}
function validatepassword(){
	var password=document.forms["student"]["password"].value;
	if(password.match(/^[A-z]{1}[a-z]*[0-9]*$/))
		{
		pswd = 1;
		console.log("true");
		document.getElementById("message_password").innerHTML="&#9989";
		document.getElementById("message_password").style.color="green";
		}
		else{
			pswd =0;
	    console.log("false");
		document.getElementById("message_password").innerHTML="&#10006";
		document.getElementById("message_password").style.color="red";
		}
}
function submit1(){
	{
		if(un==1 && pswd==1){
			return true;
		}
		else{
			return false;
			alert("please enter valid details");
		}
		
	}

}