<?php
require('connection.php');
session_start();
$dd = "cat2";
$count =0;
$sql1="alter table ".$_SESSION['slot']." ADD COLUMN ".$dd." INT";
echo $sql1;
$result=$conn->query($sql1);

$sql="select rollnumber from ".$_SESSION['slot']."";
 $result=$conn->query($sql);
          if($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
          	$temp=$row['rollnumber'];
          	$mm = $_POST[$count++];
          	$updatesql="update ".$_SESSION['slot']." set ".$dd."=".$mm." where rollnumber='".$temp."'";

            echo $updatesql. "<br>";
          	
          	$result1=$conn->query($updatesql);
          	$sqlatten="insert into marks values('".$temp."',".$count.",'".$dd."','".$mm."')";
          	$result2=$conn->query($sqlatten);
          	echo $sqlatten."<br>";
          }
      header('Location:professordashboard.php');
      }
?>