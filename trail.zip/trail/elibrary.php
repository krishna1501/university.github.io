<!doctype html>
<!DOCTYPE html>
<html>
<head>
	<title>Elibrary|Home</title>
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <script src="/dashboard.js"></script>
 
  <link rel="stylesheet" href="assets/dashboard.css">
  <link rel="stylesheet" href="assets/librarystyle.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark fixed-top outset" style="border-bottom-style: outset" >
  <div class="container-fluid">
  <!-- Brand/logo -->
  
  <a class="navbar-brand" href="dashboard.php">
    <h2>MSIT</h2>
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <span class="nav-link" href="#"></span>
    </li>
    <li class="nav-item">
    </li>
    <li class="nav-item">
      <a class="nav-link" href="logout.php"><h5>Logout</h5></a>
    </li>
  </ul>
</div>
</nav>
</div>
<div class="row" >
<div class="container-fluid">
<div class="sidenav outset" style="border-right-style: outset">
  <a href="timetable.php">TimeTable</a>
  <a href="StudentAttendence.php">Attendence</a>
  <a href="StudentMarks.php">Marks</a>
  <a href="elibrary.php" target="_self">E-Library</a>
  <a href="forum.php">Discussion Forum</a>
</div>
</div>
</div>
  <div class="container card-container" style="width:100%; padding-left:210px; padding-top: 130px;" >
   <div class="card-deck"> 
    <div class="card zoom" style="width:500px;" >
     <div class="card-body" id="ece">
      <h1 class="card-title">ECE</h1>
      <p class="card-text">Electronic and Communication Engineering</p>
      <a href="ECEbook.php"class="btn btn-warning">Open</a>
     </div>
   </div>
   <!--
   CSE card
 -->
   <div class="card zoom" style="width:500px">
    <div class="card-body" id="cse">
      <h1 class="card-title">CSE</h1>
      <p class="card-text">Computer Science Engineering</p><br>
      <a href="CSEbook.php" class="btn btn-warning">Open</a>
    </div>
  </div>
  <!--
    IT card
-->
  <div class="card zoom" style="width:500px">
    <div class="card-body" id="it">
      <h1 class="card-title">IT</h1>
      <p class="card-text">Information Technology</p><br>
      <a href="ITbook.php" class="btn btn-warning">Open</a>
    </div>
  </div>
</div>
</div>
<br>
<!--Container 2-->
<div class="container card-container" style="width:100%; padding-left:210px; padding-top:10px;">
 <div class="card-deck">
  <div class="card zoom" style="width:500px">
   <div class="card-body"id="eee">
    <h1 class="card-title">EEE</h1>
    <p class="card-text">Electrical and Electronics Engineering</p><br>
    <a href="#" class="btn btn-warning">Open</a>
   </div>
 </div>
 <div class="card zoom" style="width:500px">
  <div class="card-body" id="mech">
    <h1 class="card-title">Mech</h1>
    <p class="card-text">Mechanical Engineering</p><br><br>
    <a href="#" class="btn btn-warning">Open</a>
  </div>
</div>
<div class="card zoom" style="width:500px">
  <div class="card-body" id="civil">
    <h1 class="card-title">Civil</h1>
    <p class="card-text">Civil Engineering</p><br><br>
    <a href="#" class="btn btn-warning">Open</a>
  </div>
</div>
</div>
</div>
<br>
<!--Container 3-->
<div class="container card-container" style="width:100%; padding-left:210px; padding-top: 10px;" >

 <div class="card-deck">
  <div class="card zoom" style="width:500px">
   <div class="card-body" id="ms">
    <h1 class="card-title">MS</h1>
    <p class="card-text">(GRE,TOFEL,IELTS related exams)</p><br>
    <a href="#" class="btn btn-warning">Open</a>
   </div>
 </div>
 <div class="card zoom" style="width:500px">
  <div class="card-body" id="news">
    <h1 class="card-title">Newspapers</h1>
    <p class="card-text">Today's News</p><br><br>
    <a href="#" class="btn btn-warning">Newspapers</a>
  </div>
</div>
<div class="card zoom" style="width:500px">
  <div class="card-body" id="novel">
    <h1 class="card-title">Novels</h1>
    <p class="card-text"> which is typically published as a book.</p><br>
    <a href="#" class="btn btn-warning">Open</a>
  </div>
</div>
</div>
</div>
<br>
</body>
</html>