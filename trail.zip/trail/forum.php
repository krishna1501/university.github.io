<!DOCTYPE html>
<html>
 <head>
  <title>Discussion forum</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js">
  </script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="assets/dashboarddis.css">
  <style>
  #user{
    color:#07f8fc;
    background-color:#232222;
    padding:5px;
    opacity: 1;
    padding-left:15px;
    border-radius: 25px;
  }
     .container{
      width: 66%;
      background-color:white;
      }
    .form-control{
      background-color:#504A4A;
      color: white;
    }
  </style>
 </head>
 <body>
<?php
ob_start();
session_start();
require('connection.php');
if(isset($_SESSION['rollnumber'])){
?>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="dashboard.php"><h2>MSIT</h2></a>
    </div>
    <ul class="nav navbar-nav navbar-right" style="padding-top:25px;">
      <li><a href="dashboard.php"><span class="glyphicon glyphicon-cog"></span>Dashboard</a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
    </ul>
  </div>
</nav>
  <div class="container" style="opacity:0.9">
    <br>
    <br>
   <form method="POST" id="comment_form">
    <div class="form-group">
      <p id="user"><?php echo $_SESSION['rollnumber']?></p>
     <input type="hidden" name="comment_name" id="comment_name" class="form-control" placeholder="Enter Name" value="<?php echo $_SESSION['rollnumber']?>" />
    </div>
    <div class="form-group">
     <textarea name="comment_content" id="comment_content" class="form-control" placeholder="What is your question?"rows="5"></textarea>
    </div>
    <div class="form-group"align="right">
     <input type="hidden" name="comment_id" id="comment_id" value="0" />
     <input type="submit" name="submit" id="submit" class="btn btn-warning" value="Submit"/>
    </div>
   </form>
   <span id="comment_message"></span>
   <br/>
   <div id="display_comment"></div>
  </div>
  <?php
}else{
  header('Location:Logint.php');
}
?>
 </body>
</html>
<script>
$(document).ready(function(){
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
   url:"add_comment.php",
   method:"POST",
   data:form_data,
   dataType:"JSON",
   success:function(data)
   {
    if(data.error != '')
    {
     $('#comment_form')[0].reset();
     $('#comment_message').html(data.error);
     $('#comment_id').val('0');
     load_comment();
    }
   }
  })
 });

 load_comment();

 function load_comment()
 {
  $.ajax({
   url:"fetch_comment.php",
   method:"POST",
   success:function(data)
   {
    $('#display_comment').html(data);
   }
  })
 }

 $(document).on('click', '.reply', function(){
  var comment_id = $(this).attr("id");
  $('#comment_id').val(comment_id);
  $('#comment_name').focus();
 });
 
});
</script>
