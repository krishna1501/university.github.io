<?php
    require("connection.php");
	$rollnum= $_POST['rollnum'];
	$password=$_POST['password'];
	$ret="select * from logindetails where rollnumber='".$rollnum."' and password='".$password."'";
	$re=$conn->query($ret);
	$row=mysqli_fetch_row($re);
	if(mysqli_num_rows($re)>0)
	{
		session_start();
		$_SESSION['rollnumber']=$rollnum;
		
		$sql1="select status from logindetails where rollnumber='".$_SESSION['rollnumber']."'";
		$result1 = $conn->query($sql1);
		if($row1 = $result1->fetch_assoc()){
			if($row1['status']==0){
				header('Location:RegisterTimetable.php');
			}else{
				header('Location:dashboard.php');
		}
	}
}
	else
	{
		header('Location:Logint.php');	
	}
	?>