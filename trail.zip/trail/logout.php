<?php
session_start();
unset($_SESSION['rollnumber']);
session_destroy();
header("Location: index.html");
exit;
?>
