<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "marks";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT rollnum,subid FROM t1";
$result = $conn->query($sql);

$count = 0;

if ($result->num_rows > 0) 
{
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
		$rollnum = $row["rollnum"];
		$subid = $row["subid"];
		$internal1 = $_POST[$count++];
		$internal2 = $_POST[$count++];
		$project = $_POST[$count++];
		$external = $_POST[$count++];
		$totalmarks =$internal1+$internal2+$project+$external;
		echo $rollnum;
		echo $subid;
		echo $internal1;
		echo $internal2;
		echo $project;
		echo $external;
		echo $totalmarks;

		$sql1 = "INSERT INTO t2 (rollnum, subid, internal1, internal2, project, external, totalmarks)VALUES ('".$rollnum."', '".$subid."', '".$internal1."', '".$internal2."', '".$project."', '".$external."', '".$totalmarks."')";

		$conn->query($sql1);
    }
} 
$conn->close();
?>