 <!DOCTYPE html>
<html>
<head>
  <title>Register TimeTable</title>
  <link rel="icon" href="https://cdn3.iconfinder.com/data/icons/illustricon-tech-ii/512/calendar-256.png">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <script src="/dashboard.js"></script>
  <link rel="stylesheet" href="assets/dashboard.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


<!--            Refer RegisterTimeTable.js file for the functions            -->
<script src="assets/RegisterTimeTable.js"></script>
<!--                                                                         -->
<style>
td:hover {
    background-color: grey;
}
td{
  height:100px;
}
table{
  table-layout: auto;
}
button:dropdown{
}
</style>
<link rel="stylesheet" href="assets/UMS.css">
</head>
<body>
<?php
require('connection.php');
ob_start();
session_start();
if(isset($_SESSION['rollnumber'])){
$sql="select status from logindetails where '".$_SESSION['rollnumber']."'";
$result = $conn->query($sql);
if($row = $result->fetch_assoc()) {
  if($row['status']==1){
    $r11="";
    $r12="";
    $r21="";
    $r22="";
    $r31="";
    $r32="";
    $r41="";
    $r42="";
    $r51="";
    $r52="";
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='A1'";
    $result11 = $conn->query($sql1);
        if ($result11->num_rows > 0) {
      if($row = $result11->fetch_assoc()) {
       $r11="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='JAVA Programming'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     } 
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='A2'";
    $result12 = $conn->query($sql1);
        if ($result12->num_rows > 0) {
      if($row = $result12->fetch_assoc()) {
       $r12="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='JAVA Programming'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='B1'";
    $result21 = $conn->query($sql1);
    if ($result21->num_rows > 0) {
      if($row = $result21->fetch_assoc()) {
       $r21="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='C Programming'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."<div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='B2'";
    $result22 = $conn->query($sql1);
    if ($result22->num_rows > 0) {
      if($row = $result22->fetch_assoc()) {
       $r22="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='C Programming'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='C1'";
    $result31 = $conn->query($sql1);
    if ($result31->num_rows > 0) {
      if($row = $result31->fetch_assoc()) {
       $r31="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='DBMS'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='C2'";
    $result32 = $conn->query($sql1);
    if ($result32->num_rows > 0) {
      if($row = $result32->fetch_assoc()) {
       $r32="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='DBMS'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='D1'";
    $result41 = $conn->query($sql1);
    if ($result41->num_rows > 0) {
      if($row = $result41->fetch_assoc()) {
       $r41="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='Python'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='D2'";
    $result42 = $conn->query($sql1);
    if ($result42->num_rows > 0) {
      if($row = $result42->fetch_assoc()) {
       $r42="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='Python'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='E1'";
    $result51 = $conn->query($sql1);
    if ($result51->num_rows > 0) {
      if($row = $result51->fetch_assoc()) {
       $r51="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='French'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
    $sql1="select subid,classnumber from subject where profid=".$_SESSION['rollnumber']." and slot='E2'";
    $result52 = $conn->query($sql1);
    if ($result52->num_rows > 0) {
      if($row = $result52->fetch_assoc()) {
       $r52="<div style='background-color:yellow;padding:10px 0px 10px 0px'><b>subid:</b><abbr title='French'>sub".$row['subid']."</abbr><br/><b>clsno:</b>".$row['classnumber']."</div>";
       }
     }
?>
<nav class="navbar navbar-expand-sm navbar-dark fixed-top outset" style="border-bottom-style: outset" >
  <div class="container-fluid">
  <!-- Brand/logo -->
  
  <a class="navbar-brand" href="professordashboard.php">
    <h2>MSIT</h2>
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <span class="nav-link" href="#"></span>
    </li>
    <li class="nav-item">
    </li>
    <li class="nav-item">
      <a class="nav-link" href="logout.php"><h5>Logout</h5></a>
    </li>
  </ul>
</div>
</nav>
</div>
<div class="row">
<div class="container-fluid">
<div class="sidenav outset" style="border-right-style: outset">
  <a href="professortimetable.php" target="_self" class="active">TimeTable</a>
  <a href="attendence.php">Attendence</a>
  <a href="marksmenu.php">Marks</a>
  <a href="professorelibrary.php">E-Library</a>
  <a href="professorform.php">Discussion Forum</a>
</div>
</div>
</div>
  <div class="pt-5" style="margin-left: 200px;margin-top:50px;">
    <div class="container shadow p-4 mb-4 bg-dark shadow-lg p-3 mb-5 rounded">
      <div class="pt">
      <h3 class="text-white" style="text-align:center">Time Table</h3>
        <div class="container bg-white rounded
        " style="padding-left:50px;padding-right:50px;padding-top:20px;padding-bottom:10px">
          <table class="table table-bordered border border-dark col-*-10" id="timetable">
   <thead>
    <tr>
      <th class="bg-dark text-white">Days/Periods</th>
      <th class="bg-dark text-white">1st Period<br><i>09:00-09:50</i></th>
      <th class="bg-dark text-white">2nd Period<br><i>09:55-10:45</i></th>
      <th class="bg-dark text-white">3rd period<br><i>10:55-11:45</i></th>
      <th class="bg-dark text-white">4th Period<br><i>11:50-12:40</i></th>
      <th class="bg-dark text-white">Lunch Break<br><i>12:40-01:40</i></th>
      <th class="bg-dark text-white">5th Period<br><i>01:40-02:30</i></th>
      <th class="bg-dark text-white">6th Period<br><i>02:35-03:25</i></th>
      <th class="bg-dark text-white">7th Period<br><i>03:35-04:25</i></th>
      <th class="bg-dark text-white">8th Period<br><i>04:30-05:20</i></th>
    </tr>
  </thead>
  <tbody>
    <!--******************************Monday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Monday</th>
      <!--1st period start-->
      <td id="r1c1">
        <p id="sr1c1"><?php echo $r11;?></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r1c2">
        <p id="sr1c2"><?php echo $r31;?></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r1c3">
        <p id="sr1c3"><?php echo $r21;?></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r1c4">
        <p id="sr1c4"><?php echo $r42;?></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white"></th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r1c5">
        <p id="sr1c5"><?php echo $r22;?></p>
      </td>
      <!--5th period end-->
      
      <!--6th period start-->
      <td id="r1c6">
        <p id="sr1c6"><?php echo $r32;?></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r1c7">
        <p id="sr1c7"><?php echo $r51;?></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r1c8">
        <p id="sr1c8"><?php echo $r52;?></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Tuesday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Tuesday</th>
      <!--1st period start-->
      <td id="r2c1">
        <p id="sr2c1"><?php echo $r22;?></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
     <td id="r2c2">
        <p id="sr1c1"><?php echo $r12;?></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r2c3">
        <p id="sr2c3"><?php echo $r41;?></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r2c4">
        <p id="sr2c4"><?php echo $r21;?></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">R</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r2c5">
        <p id="sr2c5"><?php echo $r32;?></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r2c6">
        <p id="sr2c6"><?php echo $r52;?></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r2c7">
        <p id="sr2c7"><?php echo $r11;?></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r2c8">
        <p id="sr2c8"><?php echo $r51;?></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Wednesday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Wednesday</th>
      <!--1st period start-->
      <td id="r3c1">
        <p id="sr3c1"><?php echo $r21;?></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r3c2">
        <p id="sr3c2"><?php echo $r42;?></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r3c3">
        <p id="sr3c3"><?php echo $r22;?></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r3c4">
        <p id="sr3c4"><?php echo $r12;?></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">E</th>
      <!--lunch break-->
      <!--5th period start-->
        <td id="r3c5">
          <p id="sr3c5"><?php echo $r11;?></p>
        </td>
      <!--5th period end-->
      <!--6th period start-->
        <td id="r3c6">
        <p id="sr3c6"><?php echo $r11;?></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r3c7">
        <p id="sr3c7"></p>
        <p id="pr3c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r3c8">
        <p id="sr3c8"></p>
        <p id="pr3c8"></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Thursday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Thursday</th>
      <!--1st period start-->
      <td id="r4c1">
        <p id="sr4c1"><?php echo $r32;?></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
        <td id="r4c2">
        <p id="sr4c2"><?php echo $r11;?></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r4c3">
        <p id="sr4c3"><?php echo $r21;?></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r4c4">
        <p id="sr4c4"><?php echo $r31;?></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">A</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r4c5">
    <p id="sr4c5"><?php echo $r12;?></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r4c6">
        <p id="sr4c6"><?php echo $r12;?></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r4c7">
        <p id="sr4c7"></p>
        <p id="pr4c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r4c8">
        <p id="sr4c8"></p>
        <p id="pr4c8"></p>
      </td>
      <!--8th period end-->
    </tr>
    <!--******************************Friday Row**********************************-->
    <tr>
      <th scope="row" class="bg-dark text-white">Friday</th>
      <!--1st period start-->
      <td id="r5c1">
       <p id="sr5c1"><?php echo $r12;?></p>
      </td>
      <!--1st period end-->
      <!--2nd period start-->
      <td id="r5c2">
        <p id="sr5c2"><?php echo $r31;?></p>
      </td>
      <!--2nd period end-->
      <!--3rd period start-->
      <td id="r5c3">
        <p id="sr5c3"><?php echo $r41;?></p>
      </td>
      <!--3rd period end-->
      <!--4th period start-->
      <td id="r5c4">
        <p id="sr5c4"><?php echo $r22;?></p>
      </td>
      <!--4th period end-->
      <!--Lunch break-->
      <th style="text-align:center" class="bg-dark text-white">K</th>
      <!--lunch break-->
      <!--5th period start-->
      <td id="r5c5">
        <p id="sr5c5"><?php echo $r42;?></p>
      </td>
      <!--5th period end-->
      <!--6th period start-->
      <td id="r5c6">
        <p id="sr5c6"><?php echo $r41;?></p>
      </td>
      <!--6th period end-->
      <!--7th period start-->
      <td id="r5c7">
        <p id="sr5c7"></p>
        <p id="pr5c7"></p>
      </td>
      <!--7th period end-->
      <!--8th period start-->
      <td id="r5c8">
        <p id="sr5c8"></p>
        <p id="pr5c8"></p>
      </td>
      <!--8th period end-->
    </tr>
  </tbody>
</table>
<br>
       </div>
     </div>
    </div>
  </div>
  <?php
    }else{
    header('Location:RegisterTimeTable.php');
    }
    }
    }else{
    header('Location:Logint.php');
  }
?>  
</body>
</html>