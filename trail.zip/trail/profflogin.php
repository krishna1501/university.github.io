<?php
    require("connection.php");
	$rollnum= $_POST['rollnum'];
	$rollnum=str_replace("18PRO", "", $rollnum);
	$password=$_POST['password'];
	$ret="select * from professor where profid=".$rollnum." and password='".$password."'";
	echo $ret;
	$re=$conn->query($ret);
	$row=mysqli_fetch_row($re);
	if(mysqli_num_rows($re)>0)
	{
		session_start();
		$_SESSION['rollnumber']=$rollnum;
		header('Location:professordashboard.php');
	}else{
		header('Location:proflogin.php');	
	}
?>