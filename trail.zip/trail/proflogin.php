<!DOCTYPE html>
<html>
<head>
		  <title>Username Login</title>
		  <link rel="stylesheet" href="assets/login.css">
		  <meta charset="utf-8">
		  <meta name="viewport" content="width=device-width, initial-scale=1">
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
		  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script> 
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
		  <link rel="stylesheet" href="countryplugin/build/css/countrySelect.css">
		<link rel="stylesheet" href="countryplugin/build/css/demo.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script type="text/javascript" src="assets/validations.js"></script>

		  <script>
	        jQuery(window).load(function(){
	            jQuery(".hameid-loader-overlay").fadeOut(1000);
	        });
    	  </script>  
</head>
<?php
ob_start();
session_start();
if(!isset($_SESSION['rollnumber'])){
?>
<body>


	   <div class="hameid-loader-overlay">
	   	<img id="preloader" src="https://i.pinimg.com/originals/58/4b/60/584b607f5c2ff075429dc0e7b8d142ef.gif">
	   </div>
	
	<div class="container-fluid col-*-12 " >
		<div class="row">
		<div class="col-xl-1 col-md-1 col-sm-1 col-xs-0 ">
		</div>
			<div class="body col-xl-6 col-md-6 col-sm-8 col-xs-9">
					<div class="w3-bar w3-large">
					 <a type="button" href="logint.php" class="w3-bar-item w3-button w3-blue" style="width:50%;padding-top:2px"class="btn btn-warning col s3" >Username Login</a>
					 <a type="button" href="proflogin.php" class="w3-bar-item w3-button w3-red " style="width:50%;padding-top:2px">Professor Login</a>
					</div>
					
				<br/>
				<form method="POST" action="/trail/profflogin.php" name="student">
               <div class="input-group">
			    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			    <input id="email" type="text" class="form-control" name="rollnum" placeholder="Username" required onkeyup="validateusername()"/>
			  </div><label id="message_rollnum"></label>
			  <div class="input-group">
			    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
			    <input id="password" type="password" class="form-control" name="password" placeholder="Password" required onkeyup="validatepassword()"/>
			  </div><label id="message_password"></label>
               <br/>
               <center><button class = "btn btn-block btn-success" id="submit" type = "submit">Login</button></center>
               <center><a href="register.html" >Register here</a>&emsp;&emsp;<a href="home" >Home</a></center>
			</form>
					</div>
			</div>
			</div>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="countryplugin/build/js/countrySelect.js"></script>
		<script>
			$("#country_selector").countrySelect({
				//defaultCountry: "jp",
				//onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
				preferredCountries: ['in', 'us', 'au']
			});
</script>
<?php
	}else{
		header('Location:dashboard.php');
	}
?>	
</body>
</html>