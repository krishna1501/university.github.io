<!DOCTYPE html>
<html>
<head>
  <!--link rel="text/javaScript" href="RegisterTimeTable.js"-->
  <link rel="icon" href="https://cdn3.iconfinder.com/data/icons/illustricon-tech-ii/512/calendar-256.png">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="ProfessorMarksPage.css">
</head>
<body>
  <h1 style="text-align:center">Enter the marks</h1>
  <div style="padding-top:50px;">
  <div class="container pt-3 bg-dark shadow p-4 mb-4 rounded">
    <div class="pt">
     <div class="container bg-white rounded" style="padding-left:50px;padding-right:50px;padding-top:20px;padding-bottom:10px">
	<form method="POST" action="marksdb.php">	
		
        <table class="table table-bordered border border-dark">
          <thead>
           <tr>
             <th class="bg-dark text-white text-center">Roll Number</th>
             <th class="bg-dark text-white text-center">Subject ID</th>
             <th class="bg-dark text-white text-center">Internal 1 (15)</th>
             <th class="bg-dark text-white text-center">Internal 2 (15)</th>
             <th class="bg-dark text-white text-center">Project (20)</th>
             <th class="bg-dark text-white text-center">External (50)</th>
             <th class="bg-dark text-white text-center">Total Marks</th>
           </tr>
		   		 	 
         </thead>
			<?php
				$servername = "localhost";
				$username = "root";
				$password = "root";
				$dbname = "practicum";
	
				// Create connection
				$conn = new mysqli($servername, $username, $password, $dbname);
				// Check connection
				if ($conn->connect_error) 
				{
					die("Connection failed: " . $conn->connect_error);
				} 

				$sql = "SELECT rollnum,subid FROM t1";
				$result = $conn->query($sql);
				$count = 0;
				if ($result->num_rows > 0) 
				{
					// output data of each row
					while($row = $result->fetch_assoc()) 
					{
						
				?>
	
         <tbody>

           <tr>
             <td width="14%">
               <div style="text-align:center" id="rollnumber" name="Rollnumber"><?php echo $row["rollnum"] ?></div>
             </td>
             <td width="15%">
               <div style="text-align:center" id="subjectid" name="Subjectid"><?php echo  $row["subid"] ?></div>
             </td>
             <td width="10%" height="5">
               <div style="align:center">
                 <input type="text" class="form-control" id="internal1" name="<?php echo $count++; ?>"></input>
               </div>
             </td>
             <td width="10%">
               <div>
                 <input type="text" class="form-control" id="internal2" name="<?php echo $count++; ?>"></input>
               </div>
             </td>
             <td width="10%">
               <div>
                 <input type="text" class="form-control" id="projectmarks" name="<?php echo $count++; ?>"></input>
               </div>
             </td>
             <td width="10%">
               <div>
                 <input type="text" class="form-control" id="externalmarks" name="<?php echo $count++; ?>"></input>
               </div>
             </td>
             <td width="10%">
               <div class="text-center">
                 <h6 id="total_marks" name="totalM"></h6>
               </div>
             </td> 
           </tr>
		   </tbody>
		   <?php
		   	}
		}
		?>
		   </table>
       </div>
	   <br>
	   <button class="btn btn-primary btn-block" id="submittablem" type="submit">Submit</button>
	   </form>
     </div>
   </div>
 </div>
</body>
</html>
