<!doctype html>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	  <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <script>
function color(){
    if(
      document.getElementsByClassName("attendancelist").value=="absent"){
      $(".attendancelist").css("background-color","#ffb90f");
      $(".attendancelist").css("color","white");
      $(".presentorabsent").css("background-color","white");
      $(".presentorabsent").css("color","black");
      $(".present").css("background-color","white");
      $(".present").css("color","black");
      $(".absent").css("background-color","white");
      $(".absent").css("color","black");
    }}
  </script>
  <!--<script src="/dashboard.js"></script>-->
  <link rel="stylesheet" href="assets/dashboard.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <!--<script src="assets/Attendance.js1"></script>-->
</head>
<body ng-app="">
<?php
require_once('connection.php');
ob_start();
session_start();
?>
<?php
if(isset($_SESSION['rollnumber'])) {
          $sql="select slot,subname from subject where profid=".$_SESSION['rollnumber']."";
          $result=$conn->query($sql);
          if ($result->num_rows > 0) {
          if($row = $result->fetch_assoc()) {
?>
<nav class="navbar navbar-expand-sm navbar-dark fixed-top outset" style="border-bottom-style: outset" >
  <div class="container-fluid">
  <!-- Brand/logo -->
  
  <a class="navbar-brand" href="professordashboard.php">
    <h2>MSIT</h2>
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <span class="nav-link" href="#"></span>
    </li>
    <li class="nav-item">
    </li>
    <li class="nav-item">
      <a class="nav-link" href="logout.php"><h5>Logout</h5></a>
    </li>
  </ul>
</div>
</nav>
</div>
<div class="row" >
<div class="container-fluid">
<div class="sidenav outset" style="border-right-style: outset">
  <a href="professortimetable.php" target="_self">TimeTable</a>
  <a href="attendence.php">Attendence</a>
  <a href="marksmenu.php">Marks</a>
  <a href="professorelibrary.php">E-Library</a>
  <a href="professorform.php">Discussion Forum</a>
</div>
</div>
</div>
<div class="body">
<body style="background-color : #FFA500">
  <form method="POST" action="projectpp.php">
  <div class="container bg-dark shadow p-4 mb-4 rounded">
    <div>
    <label  style="color:white" id="professorlabel">Professor ID :<?php echo $_SESSION['rollnumber']?> 
    <div id="professornamedisplay"></div>
  </div>
  <div>
    <label id="subjectlabel">Subject : <?php echo $row['subname'];?></label>
    <div id="subjectdisplay"></div>
  </div>
  <div>
    <label id="presentdate">Date:<?php echo date("d/m/Y")?></labe>
    
  </div>
  <br>
    <div class="container bg-white rounded" style="padding-left:50px;padding-right:50px;padding-top:20px;padding-bottom:10px">
      <table class="table table-bordered border border-dark" id="attendancetable">
        <thead>
          <tr>
            <th class="bg-dark text-white"><center>Roll Number</center></th>
            <th class="bg-dark text-white"><center>Student name</center></th>
            <th class="bg-dark text-white"><center>Project marks</center></th>
          </tr>
        </thead>
        <tbody>
          <?php
          $_SESSION['slot']=$row['slot'];
          $count = 0;
          $sql1="select rollnumber from ".$row['slot']."";
          $result1=$conn->query($sql1);
          if($result1->num_rows > 0) {
          while($row1 = $result1->fetch_assoc()) {
            $sql2="select fullname from register where sno=(SELECT SUBSTRING((select rollnumber from logindetails where rollnumber='".$row1['rollnumber']."'), 6, 3) AS ExtractString)";
          $result2=$conn->query($sql2);
          if ($result2->num_rows > 0) {
          if($row2 = $result2->fetch_assoc()) {
          ?>
          <tr>
            <td>
              <center><div id="studentid"><?php echo $row1['rollnumber'];?></div></center>
            </td>
            <td>
              <center><div id="studentname"><?php echo $row2['fullname'];?></div></center>
            </td>
            <td >
                <div class="form-group">
                <input type="text" class="form-control" name="<?php echo $count++; ?>"></input>
              </div>
            </td>
          </tr>
          <?php
       }
     }
        }
      }
          ?>
        </tbody>
      </table>
  </div>
  <br>
  <div class="container-fluid">
  <button class="btn btn-primary btn-block" id="attendancesubmit">Submit</button>
</div>
</div>

  </div>
<?php
}
}
}else{
  header('Location:Logint.php');
}
?>
</label>
</div></label>
</div></div></form>
</body>
</html>