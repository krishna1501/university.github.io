<?php
    require("connection.php");
    $fullname = $_POST['fullname'];
    $address = $_POST['address'];
    $country= $_POST['country'];
    $gender= $_POST['gender'];
    $dob= $_POST['dob'];
    $branch= $_POST['branch'];
    $email= $_POST['email'];
    $phonenumber= $_POST['phonenumber'];
    $password= $_POST['password'];


    $sql="INSERT INTO register(fullname,address,country,gender,dob,branch,email,phonenumber,password)   VALUES ('$fullname','$address','$country','$gender','$dob','$branch','$email','$phonenumber','$password')";

    if ($conn->query($sql) === TRUE)
    {
        $ret="select sno from register where email='".$email."'";
        $re=$conn->query($ret);
		$r = $re;
		#$someStringRes = mysqli_query($connectionName,"SELECT someString from db where id=1"  ' ". $show. " ';
		#"SELECT * FROM toho_shows WHERE toho_shows.show =' ". $show. " '";
		$row=mysqli_fetch_row($re);
		$re = $row[0];
        
		if($r->num_rows>0)
        {
            $d=(date("Y"))%1000;
            $s = strval($d);
            $rollnumber=$s.$branch.$re;
            $sql1="INSERT INTO logindetails values('$rollnumber','$password',0)";
            if($conn->query($sql1)===TRUE)
            {  
                session_start();
                $_SESSION['id']=$rollnumber;
                header('Location:success.php');
            }
            else 
            {
            echo "Error: " . $sql1 . "<br>" . $conn->error;
            }
        }
        
    }
    else 
    {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
?>