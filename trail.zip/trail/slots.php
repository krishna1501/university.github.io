<?php
require('connection.php');
session_start();
if(isset($_SESSION['rollnumber'])){
	if($_POST['sub1']=="none"||$_POST['sub2']=="none"||$_POST['sub3']=="none"||$_POST['sub4']=="none"||$_POST['sub5']=="none")
	{
	  header('Location:RegisterTimeTable.php');
	}else{
		$s1=$_POST['sub1'];
		$s2=$_POST['sub2'];
		$s3=$_POST['sub3'];
		$s4=$_POST['sub4'];
		$s5=$_POST['sub5'];
		$sql="select distinct subid,classnumber from subject where slot='".$s1."'";
		$result = $conn->query($sql);
		if($row = $result->fetch_assoc()) {
		$sql1="insert into ".$s1." (subid,rollnumber,classnumber) values('".$row['subid']."','".$_SESSION['rollnumber']."','".$row['classnumber']."')";
		echo $sql1;
		$result1 = $conn->query($sql1);
		}
		$sql="select distinct subid,classnumber from subject where slot='".$s2."'";
		$result = $conn->query($sql);
		if($result->num_rows > 0) {
		if($row = $result->fetch_assoc()) {
		$sql1="insert into ".$s2." (subid,rollnumber,classnumber) values('".$row['subid']."','".$_SESSION['rollnumber']."','".$row['classnumber']."')";
		echo $sql1;
		$result1 = $conn->query($sql1);
		}
		}
		$sql="select distinct subid,classnumber from subject where slot='".$s3."'";
		$result = $conn->query($sql);
		if($row = $result->fetch_assoc()) {
		$sql1="insert into ".$s3." (subid,rollnumber,classnumber) values('".$row['subid']."','".$_SESSION['rollnumber']."','".$row['classnumber']."')";
		$result1 = $conn->query($sql1);
		}
		$sql="select distinct subid,classnumber from subject where slot='".$s4."'";
		$result = $conn->query($sql);
		if($row = $result->fetch_assoc()) {
		$sql1="insert into ".$s4." values('".$row['subid']."','".$_SESSION['rollnumber']."','".$row['classnumber']."')";
		$result1 = $conn->query($sql1);
		}
		$sql="select distinct subid,classnumber from subject where slot='".$s5."'";
		$result = $conn->query($sql);
		if($row = $result->fetch_assoc()) {
		$sql1="insert into ".$s5." (subid,rollnumber,classnumber) values ('".$row['subid']."','".$_SESSION['rollnumber']."','".$row['classnumber']."')";
		$result1 = $conn->query($sql1);
		}
		$sql1="UPDATE logindetails SET status='1' WHERE rollnumber='".$_SESSION['rollnumber']."';";
		$result1 = $conn->query($sql1);
		header('Location:timetable.php');
	}
}else{
	header('Location:Logint.php');
}
?>