<!doctype html>
<!DOCTYPE html>
<html>
<head>
		  <title>Registration</title>
		  <link rel="stylesheet" href="assets/register.css">
		  <meta charset="utf-8">
		  <meta name="viewport" content="width=device-width, initial-scale=1">
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
		  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script> 
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
		  <link rel="stylesheet" href="countryplugin/build/css/countrySelect.css">
		<link rel="stylesheet" href="countryplugin/build/css/demo.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

		  <script>
	        jQuery(window).load(function(){
	            jQuery(".hameid-loader-overlay").fadeOut(1000);
	        });
    	  </script>  
</head>
<body>
	   <div class="hameid-loader-overlay">
	   	<img id="preloader" src="https://i.pinimg.com/originals/58/4b/60/584b607f5c2ff075429dc0e7b8d142ef.gif">
	   </div>
	
	<div class="container-fluid col-*-12 " >
		<div class="row">
		<div class="col-xl-1 col-md-1 col-sm-1 col-xs-0 ">
		</div>
			<div class="body  col-xl-6 col-md-6 col-sm-8 col-xs-9">
					<div class="w3-bar w3-large">
					  <button class="w3-bar-item w3-button w3-deep-orange w3-disabled"  style="width:33.3%;padding-top:2px">Personal Details</button>
					  
					</div>
					<center>

						<?php session_start()?>
						<h1>Your Rollnumber is <?php echo $_SESSION['id'];?></h1>
						<h1>Thank You for Registering With us.For further details</h1>
						<center><a href="Logint.php" >Login</a></center>
					</center>
				<br/>
			</div>
			</div>
			</div>
</body>
</html>